#!/usr/bin/env python3
# -*- coding=utf-8 -*-

# description:
# author:jack
# create_time: 2017/12/30

"""
    desc:pass
"""


class Config:
    pass


if __name__ == '__main__':
    pass