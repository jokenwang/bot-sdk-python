#!/usr/bin/env python2
# -*- encoding=utf-8 -*-

# description:
# author:jack
# create_time: 2018/4/15

"""
    desc:pass
"""
import dueros.Log as Log
from dueros.Constants import constants
import logging

class Base(object):

    def __init__(self):
        pass
        #Log.init_log(constants.LOG_PATH)


if __name__ == '__main__':
    pass