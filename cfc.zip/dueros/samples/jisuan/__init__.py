#!/usr/bin/env python3
# -*- encoding=utf-8 -*-

# description:
# author:jack
# create_time: 2018/7/19

"""
    desc:pass
"""


class __init__:
    pass


if __name__ == '__main__':
    pass