#!/usr/bin/env python2
# -*- encoding=utf-8 -*-


import sys
from dueros.Bot import Bot
from dueros.directive.Display.RenderTemplate import RenderTemplate
from dueros.directive.Display.template.BodyTemplate1 import BodyTemplate1

reload(sys)
sys.setdefaultencoding('utf8')

class Test(Bot):

    def __init__(self, request_data):
        super(Test, self).__init__(request_data)
        self.add_launch_handler(self.launch_request)
        self.add_intent_handler('personal_income_tax.inquiry', self.getTaxSlot)

    def launch_request(self):
        """
        打开调用名
        """

        self.wait_answer()
        template = BodyTemplate1()
        template.set_title('查询个税')
        template.set_plain_text_content('欢迎进入查询个税')
        template.set_background_image('http://www.baidu.com')
        template.set_token('0c71de96-15d2-4e79-b97e-e52cec25c254')
        renderTemplate = RenderTemplate(template)
        return {
            'directives': [renderTemplate],
            'outputSpeech': r'欢迎进入查询个税'
        }

    def getTaxSlot(self):
        """
        获取槽位及逻辑处理
        """
        num = self.get_slots('sys.number')
        city = self.get_slots('sys.city')
        if num and not city:
            self.nlu.ask('sys.city')
            return {
                'reprompt': r'你所在的城市是那里呢',
                'outputSpeech': r'你所在的城市是那里呢'
            }

        if city and not num:
            self.nlu.ask('sys.number')
            return {
                'reprompt': r'你的税前工资是多少呢',
                'outputSpeech': r'你的税前工资是多少呢'
            }

        computeType = self.get_slots('compute_type')
        if not computeType:
            self.nlu.ask('compute_type')
            return {
                'outputSpeech': r'你要查询什么税种呢'
            }
        else:
            taxNum = self.computeType(num, city)
            template = BodyTemplate1()
            template.set_title('查询个税')
            content = r'你需要缴纳' + str(taxNum)
            template.set_plain_text_content(content)
            template.set_background_image('http://www.baidu.com')
            template.set_token('0c71de96-15d2-4e79-b97e-e52cec25c254')
            renderTemplate = RenderTemplate(template)
            return {
                'directives': [renderTemplate],
                'outputSpeech': content
            }


    def computeType(self, num, city):
        '''
        调用接口计算个税
        '''
        return 100


def handler(event, context):

    bot = Test(event)
    result = bot.run()
    return result
